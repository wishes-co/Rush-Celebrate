# RUSH CELEBRATE

A responsive GitHub Pages website for RUSH CELEBRATE.

## Files
- `index.html` — main website
- `style.css` — design and responsive styling
- `script.js` — small interactions
- `logo.webp` — supplied RUSH CELEBRATE logo
- `showcase.png` — supplied promotional showcase

## GitHub Pages
Upload all files to a GitHub repository and enable:
Settings → Pages → Deploy from branch → `main` → `/ (root)`.

WhatsApp order buttons are already connected to +91 99544 79114.
